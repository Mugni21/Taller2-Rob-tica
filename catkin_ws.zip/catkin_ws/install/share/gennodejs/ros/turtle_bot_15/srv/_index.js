
"use strict";

let reproducir_partida = require('./reproducir_partida.js')

module.exports = {
  reproducir_partida: reproducir_partida,
};
