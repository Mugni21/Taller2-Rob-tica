#!/usr/bin/env python3

import rospy
import numpy as np

from std_msgs.msg import String

current_msg = ""
position_msg = ""
x = 0
y = 0
theta = np.pi/2

rw=3.0
l=22.5

phi_r = 2.75*np.pi
phi_l = 2.75*np.pi

V_r=0
V_l=0

dt = 0.1 #10Hz

# setup ros publisher
pub = rospy.Publisher('Flash_bot_position', String, queue_size=10) # name of topic: /trutlebot


def callback(data):
    global current_msg
    global position_msg
    global x
    global y
    global ysss
    global theta
    global V_r
    global V_l
    #print("entro 1")
    current_msg = data.data
    #print("el mensaje es"+current_msg)
    
    if current_msg == "W":
        V_r = rw*phi_r
        V_l = rw*phi_l
    elif current_msg == "A":
        V_r = rw*phi_r
        V_l = 0
    elif current_msg == "S":
        V_r = -rw*phi_r
        V_l = -rw*phi_l
    elif current_msg == "D":
        V_r = 0
        V_l = rw*phi_l
    elif current_msg == "N":
        V_r = 0
        V_l = 0
    
    x = ( x + 0.5*(V_r+V_l)*np.cos(theta)*dt)
    y = ( y + 0.5*(V_r+V_l)*np.sin(theta)*dt)
    theta = (theta + (1/l)*(V_r-V_l)*dt)
    
    rospy.loginfo(str(x)+", "+str(y))
    position_msg = str(x)+":"+str(y)+":"+ str(theta)
    pub.publish(position_msg)
    
    
  
def listener():
    
    
    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('Lectura_pos', anonymous=True)

    rospy.Subscriber("Flash_Velocidad", String, callback)
    
    # setup ros publisher
    #pub = rospy.Publisher('Flash_bot_position', String, queue_size=10) # name of topic: /trutlebot

    #rate = rospy.Rate(10) # publish messages at 10Hz
    
    # spin() simply keeps python from exiting until this node is stopped
    
    
    
    #rospy.loginfo(str(x)+", "+str(y))
    #pub.publish(position_msg)
    rospy.spin()
        

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
